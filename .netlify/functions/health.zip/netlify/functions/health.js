var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/health.js
var health_exports = {};
__export(health_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(health_exports);

// netlify/functions/lib/prisma.js
var import_client = require("@prisma/client");
var prisma;
if (process.env.NODE_ENV === "production") {
  prisma = new import_client.PrismaClient();
} else {
  if (!global.prisma) {
    global.prisma = new import_client.PrismaClient();
  }
  prisma = global.prisma;
}
var prisma_default = prisma;

// netlify/functions/health.js
async function handler(event) {
  const checks = { db: "unknown", env: {} };
  checks.env = {
    DATABASE_URL: !!process.env.DATABASE_URL,
    JWT_SECRET: !!process.env.JWT_SECRET,
    NODE_ENV: process.env.NODE_ENV || "not set",
    STRIPE_SECRET_KEY: !!process.env.STRIPE_SECRET_KEY
  };
  try {
    const count = await prisma_default.user.count();
    checks.db = `ok (${count} users)`;
  } catch (e) {
    checks.db = `error: ${e.message}`;
  }
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: "ok", checks, timestamp: (/* @__PURE__ */ new Date()).toISOString() })
  };
}
var config = {
  path: ["/api/health", "/.netlify/functions/health"]
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
