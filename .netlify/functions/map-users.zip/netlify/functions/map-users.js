var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/map-users.js
var map_users_exports = {};
__export(map_users_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(map_users_exports);
var import_client = require("@prisma/client");
var prisma = new import_client.PrismaClient();
function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
function toRad(deg) {
  return deg * (Math.PI / 180);
}
async function handler(event) {
  if (!["GET", "POST"].includes(event.httpMethod)) {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const params = event.httpMethod === "POST" ? JSON.parse(event.body || "{}") : event.queryStringParameters || {};
    const { userId, radiusKm = 50, showAll = false, role } = params;
    const users = await prisma.user.findMany({
      where: {
        latitude: { not: null },
        longitude: { not: null },
        isBanned: false
      },
      select: {
        id: true,
        name: true,
        city: true,
        country: true,
        latitude: true,
        longitude: true,
        isTraveler: true,
        isBuyer: true
      }
    });
    if (!userId || showAll === "true" || showAll === true) {
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          users: users.map((u) => ({
            ...u,
            role: u.isTraveler ? "TRAVELER" : "BUYER"
          })),
          currentUser: null,
          nearbyUsers: []
        })
      };
    }
    const currentUser = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        city: true,
        country: true,
        latitude: true,
        longitude: true,
        isTraveler: true,
        isBuyer: true
      }
    });
    if (!currentUser) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "User not found" })
      };
    }
    const currentUserWithRole = {
      ...currentUser,
      role: currentUser.isTraveler ? "TRAVELER" : "BUYER"
    };
    if (!currentUser.latitude || !currentUser.longitude) {
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          users: users.map((u) => ({
            ...u,
            role: u.isTraveler ? "TRAVELER" : "BUYER"
          })),
          currentUser: currentUserWithRole,
          nearbyUsers: []
        })
      };
    }
    const radius = parseInt(radiusKm, 10) || 50;
    const oppositeRole = currentUser.isTraveler ? false : true;
    const usersWithDistance = users.filter((u) => u.id !== currentUser.id).map((u) => ({
      ...u,
      role: u.isTraveler ? "TRAVELER" : "BUYER",
      distance: haversineDistance(
        currentUser.latitude,
        currentUser.longitude,
        u.latitude,
        u.longitude
      )
    }));
    const nearbyUsers = usersWithDistance.filter((u) => {
      if (currentUser.isTraveler && !u.isBuyer) return false;
      if (!currentUser.isTraveler && !u.isTraveler) return false;
      return u.distance <= radius;
    }).sort((a, b) => a.distance - b.distance);
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        users: usersWithDistance,
        currentUser: currentUserWithRole,
        nearbyUsers,
        radius
      })
    };
  } catch (error) {
    console.error("Map users error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal server error" })
    };
  } finally {
    await prisma.$disconnect();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
