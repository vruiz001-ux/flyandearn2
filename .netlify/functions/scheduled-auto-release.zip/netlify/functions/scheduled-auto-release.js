var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/scheduled-auto-release.js
var scheduled_auto_release_exports = {};
__export(scheduled_auto_release_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(scheduled_auto_release_exports);

// netlify/functions/lib/prisma.js
var import_client = require("@prisma/client");
var prisma;
if (process.env.NODE_ENV === "production") {
  prisma = new import_client.PrismaClient();
} else {
  if (!global.prisma) {
    global.prisma = new import_client.PrismaClient();
  }
  prisma = global.prisma;
}
var prisma_default = prisma;

// netlify/functions/scheduled-auto-release.js
async function handler(event) {
  const authHeader = event.headers.authorization || event.headers.Authorization;
  const cronSecret = process.env.CRON_SECRET;
  const isScheduledCall = event.headers["x-netlify-event"] === "schedule";
  const hasValidSecret = cronSecret && authHeader === `Bearer ${cronSecret}`;
  if (!isScheduledCall && !hasValidSecret) {
    return {
      statusCode: 401,
      body: JSON.stringify({ error: "Unauthorized" })
    };
  }
  console.log("Starting scheduled auto-release at:", (/* @__PURE__ */ new Date()).toISOString());
  try {
    const eligibleOrders = await prisma_default.order.findMany({
      where: {
        status: "PAID",
        releaseAt: { lte: /* @__PURE__ */ new Date() }
      },
      include: {
        traveler: {
          include: {
            wallet: {
              include: { accounts: true }
            }
          }
        }
      }
    });
    console.log(`Found ${eligibleOrders.length} orders eligible for auto-release`);
    const results = {
      processed: 0,
      released: 0,
      errors: []
    };
    for (const order of eligibleOrders) {
      results.processed++;
      try {
        const wallet = order.traveler?.wallet;
        if (!wallet) {
          results.errors.push({
            orderId: order.id,
            error: "No wallet found for traveler"
          });
          continue;
        }
        const pendingAccount = wallet.accounts.find((a) => a.type === "PENDING");
        const availableAccount = wallet.accounts.find((a) => a.type === "AVAILABLE");
        if (!pendingAccount || !availableAccount) {
          results.errors.push({
            orderId: order.id,
            error: "Missing wallet accounts"
          });
          continue;
        }
        if (pendingAccount.balance < order.travelerAmount) {
          results.errors.push({
            orderId: order.id,
            error: "Insufficient pending balance"
          });
          continue;
        }
        await prisma_default.$transaction([
          // Debit from pending
          prisma_default.walletAccount.update({
            where: { id: pendingAccount.id },
            data: { balance: { decrement: order.travelerAmount } }
          }),
          // Credit to available
          prisma_default.walletAccount.update({
            where: { id: availableAccount.id },
            data: { balance: { increment: order.travelerAmount } }
          }),
          // Create ledger entry
          prisma_default.ledgerEntry.create({
            data: {
              type: "RELEASE",
              status: "COMPLETED",
              amount: order.travelerAmount,
              currency: order.currency,
              debitAccountId: pendingAccount.id,
              creditAccountId: availableAccount.id,
              referenceType: "ORDER",
              referenceId: order.id,
              idempotencyKey: `scheduled-release-${order.id}-${Date.now()}`,
              description: `Scheduled auto-release for order ${order.id}`
            }
          }),
          // Update order status
          prisma_default.order.update({
            where: { id: order.id },
            data: {
              status: "COMPLETED",
              completedAt: /* @__PURE__ */ new Date()
            }
          }),
          // Update related request
          prisma_default.request.update({
            where: { id: order.requestId },
            data: { status: "COMPLETED" }
          })
        ]);
        await prisma_default.auditLog.create({
          data: {
            adminId: null,
            // System action
            action: "AUTO_RELEASE",
            entityType: "ORDER",
            entityId: order.id,
            metadata: {
              amount: order.travelerAmount,
              currency: order.currency,
              travelerId: order.travelerId,
              triggeredBy: "scheduled_function"
            }
          }
        });
        results.released++;
        console.log(`Released order ${order.id} - \u20AC${order.travelerAmount}`);
      } catch (error) {
        console.error(`Error processing order ${order.id}:`, error);
        results.errors.push({
          orderId: order.id,
          error: error.message
        });
      }
    }
    console.log("Auto-release completed:", results);
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        results
      })
    };
  } catch (error) {
    console.error("Auto-release function error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Auto-release function failed",
        message: error.message
      })
    };
  }
}
var config = {
  schedule: "@daily"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
